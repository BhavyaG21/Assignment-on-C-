﻿using System;
using System.Linq;

namespace ConsoleApp_Assesment
{
    class Booking
    {
        string tickets;
        int noOfTickets;
        int maxTickets = 20;
        int i;
        string[] Categories = { "thriller", "action", "comedy", "drama" };
        string arrayval;
        // private static object userName;
        string userName;
        private object tickebooking = new object();


        public bool Display_Tickets()
        {
            Console.WriteLine("\n");
            Console.WriteLine("Enter your name");
            userName = Console.ReadLine();
            /* do
             {*/

            if (string.IsNullOrEmpty(userName) || userName.All(char.IsDigit))
            {
                Console.WriteLine("Invaild input! Name should be letters only.");
                Environment.Exit(0);
            }
            /*}
            while (Console.ReadKey(true).Key != ConsoleKey.Enter);*/
            Console.WriteLine("\n");
            Console.WriteLine("......Booking Details......");
            Console.WriteLine("Name:" + userName);
            Console.WriteLine("Total number of tickets:" + noOfTickets);
            Console.WriteLine("Category:" + arrayval);
            Console.WriteLine("\n");
            Console.WriteLine("Confirm your ticket below");
            Console.Write("1. Confirm  ");
            Console.WriteLine("2. Cancel");
            switch (Console.ReadLine())
            {
                case "1":
                    Confirm();
                    return true;

                case "2":
                    Cancel();
                    return false;
                default:
                    return false;
            }



        }
        public void Confirm()
        {
            Console.ForegroundColor = ConsoleColor.Green;

            Console.WriteLine($"The user {userName} has been booked {noOfTickets} tickets successfully.");

        }
        public void Cancel()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Ticket booking has been canceled.");

        }
        public void Ticket_booking()
        {

            lock (tickebooking)
            {
                Console.WriteLine("Ticket Booking Application\n");
                Console.WriteLine("Do you want to book movie tickects? Say yes or no");
                tickets = Console.ReadLine();

                if (tickets == "yes" || tickets == "YES" || tickets == "Yes")
                {
                    Console.WriteLine("\n");
                    Console.Write("Categories: ");
                    try
                    {
                        for (i = 0; i <= 3; i++)
                        {
                            Console.Write("{0} ", Categories[i]);
                        }
                        Console.Write("\n");
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                    }
                    while (true)
                    {
                        Console.Write("Select Category:");
                        arrayval = Console.ReadLine();


                        try
                        {

                            if (Categories.Contains(arrayval))

                            {
                                Console.WriteLine("Enter the number of tickets to be booked");
                                noOfTickets = Convert.ToInt32(Console.ReadLine());
                                break;
                            }
                            else
                            {
                                Console.WriteLine("Invalid option");


                            }

                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex);
                        }

                    }

                    if (noOfTickets > maxTickets)
                    {
                        Console.WriteLine("Entered number exceeded the available number of tickets");
                    }
                }
                else if (tickets == "no" || tickets == "NO" || tickets == "No")
                {
                    Environment.Exit(0);
                }
                else
                {

                    Console.WriteLine("Invalid option! Try again");
                    Environment.Exit(0);



                }
            }
        }

    }



    class Start_booking
    {
        static void Main(string[] args)
        {

            Booking booking = new Booking();
            // booking.Selectoptions();

            booking.Ticket_booking();
            booking.Display_Tickets();


        }
    }
}
